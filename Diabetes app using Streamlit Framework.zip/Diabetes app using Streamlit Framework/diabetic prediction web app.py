#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 18 15:22:30 2022

@author: ubuntu
"""

import numpy as np
import pickle
import streamlit as st

loaded_model = pickle.load(open('/home/ubuntu/Desktop/web/trained_model.sav','rb'))

def diabetes_prediction(input_data):
    input_data = (6,148,72,35,0,33.6,0.627,50)

    input_data_as_numpy_array = np.asarray(input_data)

    input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

    prediction = loaded_model.predict(input_data_reshaped)

    if (prediction[0] == 0):
        return 'the person is not diabetic'
    else:
        return 'the papu is diabetic patient'
    
    
def main():
    st.title('Diabetes Prediction web appPregnencies ')
    
    Pregnancies = st.text_input('number of pregnancies')
    Glucose  = st.text_input('glocose level')
    BloodPressure  = st.text_input('Blood Pressure value')
    SkinThickness = st.text_input('Skin Thickness value')
    Insulin  = st.text_input('Insulin Level')
    BMI  = st.text_input('BMI value')
    DiabetesPedigreeFunction = st.text_input('DiabetesPedigreeFunction value')
    Age  = st.text_input('Age of the Person')
    
    diagnosis = ''
    
    if st.button('Diabetes Test Results'):
        diagnosis = diabetes_prediction([Pregnancies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,Age])
        
    st.success(diagnosis)
    
if __name__ == '__main__':
    main()
    
    
    
    

